# Contributing
- PR's are welcome 
- If you can stick to the PEP-8 guideline and comment your code :D
